import SwiftUI
import Combine

/// Shared, observable settings for the Options screen.
final class AppState: ObservableObject {
    static let shared = AppState()

    /// Target backlight brightness, 0...100.
    @Published var brightness: Double = 80

    /// Fill-light color. White by default; user can pick a custom color.
    @Published var color: Color = .white

    /// UI language (defaults to the system language).
    @Published var lang: Lang = .system

    private init() {}
}
